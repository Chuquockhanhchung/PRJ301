/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entry;

/**
 *
 * @author ADMIN
 */
public class Voucher {
    private int id;
    private String voucher;
    private float sale;

    public Voucher() {
    }

    public Voucher(int id, String voucher, float sale) {
        this.id = id;
        this.voucher = voucher;
        this.sale = sale;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public float getSale() {
        return sale;
    }

    public void setSale(float sale) {
        this.sale = sale;
    }

    @Override
    public String toString() {
        return "Voucher{" + "id=" + id + ", voucher=" + voucher + ", sale=" + sale + '}';
    }
    
    
}
