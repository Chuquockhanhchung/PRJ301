/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entry;

/**
 *
 * @author ADMIN
 */
public class Cart {
    private int accID;
    private int proID;
    private int amount;

    public Cart() {
    }

    public Cart(int accID, int proID, int amount) {
        this.accID = accID;
        this.proID = proID;
        this.amount = amount;
    }

    public int getAccID() {
        return accID;
    }

    public void setAccID(int accID) {
        this.accID = accID;
    }

    public int getProID() {
        return proID;
    }

    public void setProID(int proID) {
        this.proID = proID;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Cart{" + "accID=" + accID + ", proID=" + proID + ", amount=" + amount + '}';
    }
    
}
