/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entry;

import java.sql.Date;

/**
 *
 * @author ADMIN
 */
public class Order {
    private int aid;
    private int pid;
    private int amount;
    private Date date;

    public Order() {
    }

    public Order(int aid, int pid, int amount, Date date) {
        this.aid = aid;
        this.pid = pid;
        this.amount = amount;
        this.date = date;
    }

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Order{" + "aid=" + aid + ", pid=" + pid + ", amount=" + amount + ", date=" + date + '}';
    }
    
}
