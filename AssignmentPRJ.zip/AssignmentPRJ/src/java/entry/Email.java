/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entry;


import com.sun.mail.imap.IMAPMessage;
import dal.DAO;
import java.net.PasswordAuthentication;
import java.util.ArrayList;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.activation.DataHandler;
import javax.activation.DataSource;


/**
 *
 * @author ADMIN
 */
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {
    private String from;
    public Email() {
    }

    public Email(String from) {
        this.from = from;
    }
    
    
    public  void sendEmail(ArrayList<Cart> a, String mail, String name, String total) {
        final String from = "chuquockhanhchung@gmail.com";
        final String pass = "lrbq waeg mugb jkxr";
        
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        
        // Create authentication 
        Authenticator auth = new Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(from, pass);
            }
        };
        
        // Get session
        Session session = Session.getInstance(properties, auth);
        
        // Send email
        String to = mail;
        MimeMessage msg = new MimeMessage(session);
        
        try {
            // Set content type
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            
            // Set sender
            msg.setFrom(new InternetAddress(from));
            
            // Set recipient
            msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            
            // Set subject
            msg.setSubject("Confirm transaction!");
            String cartS="";
            DAO dao = new DAO();
            for (Cart cart : a) {
                Product p = dao.getProductByID(cart.getProID());
                cartS+=p.getName()+" Amount: "+cart.getAmount()+"\n";
            }
            // Set content
            msg.setText("Dear "+name+",\n" +
"\n" +
"This is to confirm that we have received your payment for invoice \n"+cartS+"The total amount received is "+total+"$. Thank you for your timely payment. We appreciate your business and look forward to serving you in the future.\n" +
"\n" +
"Best regards,\nChun", "UTF-8");
            
            // Send email
            Transport.send(msg);
            
            System.out.println("Email sent successfully.");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}

