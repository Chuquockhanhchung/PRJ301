/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import context.DBContext;
import entry.Account;
import entry.Cart;
import entry.Category;
import entry.Order;
import entry.Product;
import entry.Voucher;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class DAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
//    public List<Product> getAllProduct(){
//        List<Product> list = new ArrayList<>();
//        String query="select * from product";
//        try{
//            conn =  new DBContext().DBContext();
//            ps=conn.prepareStatement(query);
//            rs=ps.executeQuery();
//            while(rs.next()){
//                list.add(new Product(rs.getInt(1), 
//                        rs.getString(2), 
//                        rs.getString(3), 
//                        rs.getDouble(4),
//                        rs.getInt(5),
//                        rs.getString(6), 
//                        rs.getString(7)));
//            }
//        }catch(Exception e){
//            
//        }
//        return list;
//    }

    public List<Product> getProductByPaging(int page) {
        List<Product> list = new ArrayList<>();
        DAO dao = new DAO();
        int p = (dao.getNumberProduct() % 6 == 0) ? 0 : 1;
        int numberpage = dao.getNumberProduct() / 6 + p;
        String query = "SELECT  *\n"
                + "FROM    ( SELECT    ROW_NUMBER() OVER ( ORDER BY id ) AS RowNum, *\n"
                + "          FROM      product\n"
                + "          WHERE    Amount>0\n"
                + "        ) AS RowConstrainedResult\n"
                + "WHERE   RowNum >= ?\n"
                + "    AND RowNum <= ?\n"
                + "ORDER BY RowNum";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            if (page == numberpage) {
                ps.setInt(1, (page - 1) * 6 + 1);
                ps.setInt(2, dao.getNumberProduct());
            } else {
                ps.setInt(1, (page - 1) * 6 + 1);
                ps.setInt(2, page * 6);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getDouble(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public List<Product> getProductByPagingCat(int page, int cid) {
        List<Product> list = new ArrayList<>();
        DAO dao = new DAO();
        int p = (dao.getNumberProduct() % 6 == 0) ? 0 : 1;
        int numberpage = dao.getNumberProduct() / 6 + p;
        String query = "SELECT  *\n"
                + "FROM    ( SELECT    ROW_NUMBER() OVER ( ORDER BY id ) AS RowNum, *\n"
                + "          FROM      product\n"
                + "          WHERE    Amount>0 and cateID=?\n"
                + "        ) AS RowConstrainedResult\n"
                + "WHERE   RowNum >= ?\n"
                + "    AND RowNum <= ?\n"
                + "ORDER BY RowNum";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            if (page == numberpage) {
                ps.setInt(1, cid);
                ps.setInt(2, (page - 1) * 6 + 1);
                ps.setInt(3, dao.getNumberProduct());
            } else {
                ps.setInt(1, cid);
                ps.setInt(2, (page - 1) * 6 + 1);
                ps.setInt(3, page * 6);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getDouble(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public List<Category> getAllCategory() {
        List<Category> list = new ArrayList<>();
        String query = "select * from Category";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Category(rs.getInt(1),
                        rs.getString(2)
                ));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public Product getLast() {
        String query = "select * from product p order by p.id desc";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                if (rs.getInt(5) > 0) {
                    return new Product(rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getDouble(4),
                            rs.getInt(5),
                            rs.getString(6),
                            rs.getString(7));
                }
            }
        } catch (Exception e) {

        }
        return null;
    }

    public List<Product> getProductByCat(String cid) {
        List<Product> list = new ArrayList<>();
        String query = "select * from product where cateID=?";

        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, cid);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getInt(5),
                        rs.getString(6),
                        rs.getString(7)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public Product getProductByID(int id) {
        String query = "select * from product p where p.id=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getInt(5),
                        rs.getString(6),
                        rs.getString(7));
            }
        } catch (Exception e) {

        }
        return null;
    }

    public Account getAccountByID(String id) {
        String query = "select * from Account p where p.uID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Account(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getInt(5));
            }
        } catch (Exception e) {

        }
        return null;
    }

    public List<Product> getProductByTxt(String id) {
        List<Product> list = new ArrayList<>();
        id = "%" + id + "%";
        String query = "select * from product p where p.[name] like ?";

        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getInt(5),
                        rs.getString(6),
                        rs.getString(7)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public List<Product> getProductPageByTxt(int page,String id) {
        List<Product> list = new ArrayList<>();
       
        DAO dao = new DAO();
        int p = (dao.getNumberProductByTxT(id)% 6 == 0) ? 0 : 1;
        int numberpage = dao.getNumberProductByTxT(id)/ 6 + p;
         id = "%" + id + "%";
        String query = "SELECT  *\n"
                + "FROM    ( SELECT    ROW_NUMBER() OVER ( ORDER BY id ) AS RowNum, *\n"
                + "          FROM      product\n"
                + "          WHERE    Amount>0 and [name] like ?\n"
                + "        ) AS RowConstrainedResult\n"
                + "WHERE   RowNum >= ?\n"
                + "    AND RowNum <= ?\n"
                + "ORDER BY RowNum";

        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            
            if (page == numberpage) {
                ps.setString(1, id );
                ps.setInt(2, (page - 1) * 6 + 1);
                ps.setInt(3, dao.getNumberProduct());
            } else {
                ps.setString(1, id );
                ps.setInt(2, (page - 1) * 6 + 1);
                ps.setInt(3, page * 6);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getDouble(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public Account login(String user, String pass) {
        String query = "select * from Account where [user]=? and pass =?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, user);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Account(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getInt(5));
            }
        } catch (Exception e) {

        }
        return null;
    }

    public Account CheckAcc(String user) {
        String query = "select * from Account where [user]=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, user);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Account(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getInt(5));
            }
        } catch (SQLException e) {

        }
        return null;
    }

    public void signUp(String user, String pass) {
        String query = "insert into Account values (?,?,0,0)";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, user);
            ps.setString(2, pass);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public List<Product> getProductBySellID(int id) {
        List<Product> list = new ArrayList<>();

        String query = "select * from product p where p.sell_ID=?";

        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getInt(5),
                        rs.getString(6),
                        rs.getString(7)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public void deleteAccount(int id) throws SQLException {
        String query = "delete from Account where uID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }

    public void deleteProduct(int id) throws SQLException {
        String query = "delete from product where id=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }

    public void editAccount(String id, String user, String pass) {
        String query = "update Account set [user]=?,pass=? where uID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, user);
            ps.setString(2, pass);
            ps.setString(3, id);
            ps.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public void editProduct(String name, String image, String price,
            String title, String description, String category, String pid) {
        String query = "update product\n"
                + "set [name] = ?,\n"
                + "[image] = ?,\n"
                + "price = ?,\n"
                + "title = ?,\n"
                + "[description] = ?,\n"
                + "cateID = ?\n"
                + "where id = ?";
        try {
            conn = new DBContext().DBContext();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, image);
            ps.setString(3, price);
            ps.setString(4, title);
            ps.setString(5, description);
            ps.setString(6, category);
            ps.setString(7, pid);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }

    public List<Account> loadAcc() {
        String query = "select * from Account where isAdmin = 0";
        List<Account> list = new ArrayList<>();
        try {
            conn = new DBContext().DBContext();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Account(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getInt(5)));
            }
        } catch (SQLException e) {
        }
        return list;
    }

    public Cart checkCart(String accID, String proID) {
        String query = "select* from Cart where AccountID =? AND ProductID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, accID);
            ps.setString(2, proID);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Cart(rs.getInt(1), rs.getInt(2), rs.getInt(3));
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void deleteCart(int pid, int aid, int amount) {
        String query = "delete from Cart where AccountID=? And ProductID=?;\n"
                + "   update product set Amount=? where id=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, aid);
            ps.setInt(2, pid);
            ps.setInt(3, amount);
            ps.setInt(4, pid);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }

    public List<Cart> loadAllCart() {
        List<Cart> list = new ArrayList<>();
        String query = "select * from Cart ";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Cart(rs.getInt(1), rs.getInt(2), rs.getInt(3)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Cart loadCart(int accID, int pid) {
        String query = "select * from Cart where AccountID=? AND ProductID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, accID);
            ps.setInt(2, pid);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Cart(rs.getInt(1), rs.getInt(2), rs.getInt(3));
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Cart> loadCart(int accID) {
        List<Cart> list = new ArrayList<>();
        String query = "select * from Cart where AccountID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, accID);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Cart(rs.getInt(1), rs.getInt(2), rs.getInt(3)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public void updateCart(int accID, int proID, int amountcart, int amountpro) {
        String query = "update Cart set Amount=? where AccountID=? AND ProductID=?;"
                + "update product set amount=? where id=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, amountcart);
            ps.setInt(2, accID);
            ps.setInt(3, proID);
            ps.setInt(4, amountpro);
            ps.setInt(5, proID);
            ps.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public void addCart(int accID, int proID, int amountold, int amountnew) {
        String query = "insert into Cart values(?,?,?);"
                + "update product set amount=? where id=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, accID);
            ps.setInt(2, proID);
            ps.setInt(3, amountnew);
            ps.setInt(4, amountold);
            ps.setInt(5, proID);
            ps.executeUpdate();
        } catch (SQLException e) {
        }

    }

    public void addProduct(String name, String image, String price, String amount, String title, String description, String category, int sid) throws SQLException {
        String query = "insert into product values (?,?,?,?,?,?,?,?)";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, image);
            ps.setDouble(3, Double.parseDouble(price));
            ps.setInt(4, Integer.parseInt(amount));
            ps.setString(5, title);
            ps.setString(6, description);
            ps.setInt(7, Integer.parseInt(category));
            ps.setInt(8, sid);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }

    public List<Voucher> getAllVoucher() {
        List<Voucher> list = new ArrayList<>();
        String query = "select * from voucher";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Voucher(rs.getInt(1),
                        rs.getString(2),
                        rs.getFloat(3)));
            }
        } catch (SQLException e) {
        }
        return list;
    }

    public int getAmountProduct(int aid) {
        String query = "select sum(c.Amount) from Cart c where AccountID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, aid);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
        }
        return 0;
    }

    public void deleteCard(int aid) {
        String query = "delete from [Cart] where AccountID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, aid);
            ps.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public void checkOut(int aid, int pid, int amount) {
        String query = "insert into [Order] values(?,?,?,?);";
        long millis = System.currentTimeMillis();
        Date date = new Date(millis);
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, aid);
            ps.setInt(2, pid);
            ps.setInt(3, amount);
            ps.setDate(4, date);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }

    public ArrayList<Order> getAllOrder() {
        ArrayList<Order> list = new ArrayList<>();
        String query = "select * from [Order]";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Order(rs.getInt(1),
                        rs.getInt(2),
                        rs.getInt(3),
                        rs.getDate(4)));
            }
        } catch (SQLException e) {
        }
        return list;
    }

    public int getNumberProduct() {
        String query = "SELECT COUNT(*) FROM product where Amount>0";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
        }
        return 0;
    }
    public int getNumberProductByTxT(String id) {
        String query = "SELECT COUNT(*) FROM product where Amount>0 and [name] like ?";
        id = "%" + id + "%";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
        }
        return 0;
    }

    public int getNumberProductbyCat(int cid) {
        String query = "SELECT COUNT(*) FROM product where Amount>0 and cateID=?";
        try {
            conn = new DBContext().DBContext();
            ps = conn.prepareStatement(query);
            ps.setInt(1, cid);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
        }
        return 0;
    }

    public static void main(String[] args) throws SQLException {
        DAO dao = new DAO();
        //dao.addCart(3, 5, 7, 993);
//        Cart b=dao.loadCart(3, 5);
//dao.deleteCart(3, 5, 1000);

//dao.addProduct("abc", "abc", "300","1000", "abc", "abc", "3", 3);
        //    List<Cart> list = dao.loadAllCart(); 
        List<Product> a = dao.getProductPageByTxt(1,"g");
        for (Product product : a) {
            System.out.println(product);
        }
        int ab = dao.getNumberProductByTxT("g");
        System.out.println(ab);

    }

}
