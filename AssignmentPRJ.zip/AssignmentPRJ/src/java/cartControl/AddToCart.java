/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package cartControl;

import dal.DAO;
import entry.Account;
import entry.Category;
import entry.Product;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class AddToCart extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddToCart</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddToCart at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String id = request.getParameter("pid");
        int pid=Integer.parseInt(id);
        
      
        DAO dao = new DAO();
        String aid=request.getParameter("aid");
        int accid=Integer.parseInt(aid);
        String quantity =request.getParameter("quantity");
        int quan=0;
        try {
             quan=Integer.parseInt(quantity);
        } catch (NumberFormatException e) {
        Product p = dao.getProductByID(Integer.parseInt(id));
        Product last = dao.getLast();
        List<Category> listC = dao.getAllCategory();
        request.setAttribute("listCC", listC);
        request.setAttribute("detail", p);
        request.setAttribute("last", last);
        request.getRequestDispatcher("Detail.jsp").forward(request, response);
        }
        if(dao.checkCart(aid, id)==null){
            dao.addCart(accid, pid, dao.getProductByID(pid).getAmount()-Integer.parseInt(quantity), Integer.parseInt(quantity));
        }else{
            int totalAmount=Integer.parseInt(quantity)+dao.checkCart(aid,id).getAmount();
        dao.updateCart(accid, pid,totalAmount , dao.getProductByID(pid).getAmount()-Integer.parseInt(quantity));
    }
        List<Product> list =new ArrayList<>();
        if(request.getParameter("pg")==null){
            list =  dao.getProductByPaging(1);
            request.setAttribute("pgi",1);
        }else{
            if(Integer.parseInt(request.getParameter("pg"))==0){
                list =  dao.getProductByPaging(1);
            request.setAttribute("pgi",1);
            }else{
             list =  dao.getProductByPaging(Integer.parseInt(request.getParameter("pg")));
             request.setAttribute("pgi",Integer.parseInt(request.getParameter("pg")) );
            }
        }
        List<Category> listC = dao.getAllCategory();
        Product last = dao.getLast();
        
        //b2: set data to jsp
        HttpSession session = request.getSession();
        Account a = (Account) session.getAttribute("acc");
        int amountCart=dao.getAmountProduct(a.getId());
        int p= (dao.getNumberProduct()%6==0)?0:1;
        List<Integer> page = new ArrayList<>();
        for(int i=1;i<=dao.getNumberProduct()/6+p;i++){
            page.add(i);
        }
        request.setAttribute("s", 1);
        request.setAttribute("nb", dao.getNumberProduct());
        request.setAttribute("page", page);
        session.setAttribute("am", amountCart);
        request.setAttribute("listP", list);
        request.setAttribute("listCC", listC);
        request.setAttribute("p", last);
        request.getRequestDispatcher("Home.jsp").forward(request, response);
        
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
